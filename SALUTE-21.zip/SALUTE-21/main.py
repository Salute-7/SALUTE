import pygame
import random
import math
import time
from datetime import datetime
pygame.init()

width, height = 700, 700
screen = pygame.display.set_mode((width, height))
pygame.display.set_caption('Новогодний Фейерверк с отсчётом')
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

def create_firework(x, y):
    color = random.choice(['#FF3366', '#33FF66', '#3366FF', '#FF33CC', '#FFFF33', '#FF6600', '#33FFFF'])
    firework = []
    for i in range(50):  
        angle = random.uniform(0, 2 * math.pi) 
        speed = random.uniform(5, 12) 
        firework.append({
            'x': x,
            'y': y,
            'angle': angle,
            'length': 0, 
            'speed': speed,
            'max_length': random.uniform(50, 120), 
            'color': color,
            'line_width': 3,  
        })
    return firework


def update_fireworks():
    global fireworks, last_firework_time

    screen.fill(BLACK) 
    for firework in fireworks:
        for line in firework:
            if line['length'] < line['max_length']:
                line['length'] += line['speed'] * 0.1  
            x_end = line['x'] + line['length'] * math.cos(line['angle'])
            y_end = line['y'] + line['length'] * math.sin(line['angle'])
            pygame.draw.line(screen, pygame.Color(line['color']), 
                             (int(line['x']), int(line['y'])), 
                             (int(x_end), int(y_end)), 
                             int(line['line_width']))
            line['line_width'] = max(1, line['line_width'] - 0.05)
        if all(line['length'] >= line['max_length'] for line in firework):
            fireworks.remove(firework)
    if time.time() - last_firework_time > 1:
        fireworks.append(create_firework(random.randint(50, 350), random.randint(50, 350)))
        last_firework_time = time.time()
    now = datetime.now()
    new_year = datetime(now.year + 1, 1, 1)
    delta = new_year - now
    countdown_text = f"До Нового года осталось:\n {delta.days} дн {delta.seconds // 3600:02} ч {(delta.seconds % 3600) // 60:02} мин {delta.seconds % 60:02} сек"
    countdown_lines = countdown_text.splitlines()
    font = pygame.font.SysFont("Arial", 24, bold=True)  
    y_offset = height // 2 - 50  

    for line in countdown_lines:
        text_surface = font.render(line, True, WHITE)
        text_rect = text_surface.get_rect(center=(width // 2, y_offset))  
        screen.blit(text_surface, text_rect)
        y_offset += 30  

    pygame.display.update() 


running = True
fireworks = []
last_firework_time = time.time()
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    update_fireworks()

    pygame.time.delay(30)  

pygame.quit()
